// 弹框关闭、移除
function hid(){	
  var index = $(this).index();
  $(".dialog").removeClass("dialog-show");    
};
function remove(){
  var index = $(this).index();
  $(".dialog").eq(index).remove();
};
//END
