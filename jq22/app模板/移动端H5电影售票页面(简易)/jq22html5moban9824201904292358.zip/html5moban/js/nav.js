$("body .container").append('<footer class="bottom-nav"><ul class="ulnav"><li><a href="index.html"><span class="icon menu1"></span><span>首 页</span> </a></li><li><a href="my.html"><span class="icon menu2"></span> <span>我 的</span> </a></li><li><a href="help.html"><span class="icon menu3"></span> <span>帮 助</span> </a></li></ul></footer>'); 
 
 

//菜单定位
thisURL = document.URL;
$(".ulnav li").each(function(){
	if(this.href == thisURL){
		$(this).addClass("active"); 
		return false;
	}
});
$(".ulnav li").click(function(){
	$(".ulnav li").removeClass("active");
	$(this).addClass("active");
	setTimeout("toTop()", 50);
});
